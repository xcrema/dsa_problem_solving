package listeners;

public class FileLogListener implements LogListener{
    @Override
    public void listenDebugLogs(String message) {

    }

    @Override
    public void listenWarnLogs(String message) {

    }

    @Override
    public void listenInfoLogs(String message) {

    }

    @Override
    public void listenErrorLogs(String message) {

    }
}
