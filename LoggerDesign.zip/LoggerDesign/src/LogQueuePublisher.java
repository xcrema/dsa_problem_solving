public interface LogQueuePublisher {

    void publishDebugMessage(String message);
}
